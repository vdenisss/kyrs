package com.example.kyrsovaya4kyrs.repository;

import com.example.kyrsovaya4kyrs.model.Feetback;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FeedbackRepository extends JpaRepository<Feetback, Integer> {
}
