package com.example.kyrsovaya4kyrs.service;

import com.example.kyrsovaya4kyrs.model.Role;
import com.example.kyrsovaya4kyrs.model.SystemUser;
import com.example.kyrsovaya4kyrs.repository.RoleRepository;
import com.example.kyrsovaya4kyrs.repository.SystemUserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserService implements UserServiceInterface{

    @Autowired
    SystemUserRepository systemUserRepo;

    @Autowired
    RoleRepository roleRepo;

    @Override
    public void createUser(String email, String password, int idRole) {
        SystemUser user =  new SystemUser(email, password, idRole);
        systemUserRepo.save(user);
    }

    @Override
    public SystemUser login(String email, String password) {
        List<SystemUser> users = systemUserRepo.findAll();
        for (SystemUser user: users) {
            if(user.getEmail().equals(email) && user.getPassword().equals(password)){
                return user;
            }
        }
        return null;
    }

    @Override
    public String getNameRole(int idRole) {
        return roleRepo.findById(idRole).get().getName();
    }

    @Override
    public SystemUser updateUser(SystemUser user) {
        systemUserRepo.save(user);
        return getUser(user.getIdUser());
    }

    @Override
    public SystemUser getUser(int idUser) {
        return systemUserRepo.findById(idUser).get();
    }
}
