package com.example.kyrsovaya4kyrs.model;

import jakarta.persistence.*;

import java.util.Objects;

@Entity
public class Client {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id_client")
    private int idClient;
    @Basic
    @Column(name = "name")
    private String name;
    @Basic
    @Column(name = "id_address")
    private int idAddress;
    @Basic
    @Column(name = "rating")
    private double rating;

    public int getIdClient() {
        return idClient;
    }

    public void setIdClient(int idClient) {
        this.idClient = idClient;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getIdAddress() {
        return idAddress;
    }

    public void setIdAddress(int idAddress) {
        this.idAddress = idAddress;
    }

    public double getRating() {
        return rating;
    }

    public void setRating(double rating) {
        this.rating = rating;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Client client = (Client) o;
        return idClient == client.idClient && idAddress == client.idAddress && Double.compare(client.rating, rating) == 0 && Objects.equals(name, client.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idClient, name, idAddress, rating);
    }

    @Override
    public String toString() {
        return "Client{" +
                "idClient=" + idClient +
                ", name='" + name + '\'' +
                ", idAddress=" + idAddress +
                ", rating=" + rating +
                '}';
    }
}
