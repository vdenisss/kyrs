package com.example.kyrsovaya4kyrs.service;

import com.example.kyrsovaya4kyrs.model.Client;

public interface ClientServiceInterface {
    Client createClient(Client client);
    Client getClient(int idClient);
}
