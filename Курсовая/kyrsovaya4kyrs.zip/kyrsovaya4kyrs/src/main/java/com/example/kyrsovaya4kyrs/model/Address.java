package com.example.kyrsovaya4kyrs.model;

import jakarta.persistence.*;

import java.util.Objects;

@Entity
public class Address {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id_address")
    private int idAddress;
    @Basic
    @Column(name = "city")
    private String city;
    @Basic
    @Column(name = "street")
    private String street;
    @Basic
    @Column(name = "number_house")
    private String numberHouse;
    @Basic
    @Column(name = "entrance")
    private String entrance;
    @Basic
    @Column(name = "floor")
    private String floor;
    @Basic
    @Column(name = "door_number")
    private String doorNumber;
    @Basic
    @Column(name = "flat")
    private String flat;

    public int getIdAddress() {
        return idAddress;
    }

    public void setIdAddress(int idAddress) {
        this.idAddress = idAddress;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public String getNumberHouse() {
        return numberHouse;
    }

    public void setNumberHouse(String numberHouse) {
        this.numberHouse = numberHouse;
    }

    public String getEntrance() {
        return entrance;
    }

    public void setEntrance(String entrance) {
        this.entrance = entrance;
    }

    public String getFloor() {
        return floor;
    }

    public void setFloor(String floor) {
        this.floor = floor;
    }

    public String getDoorNumber() {
        return doorNumber;
    }

    public void setDoorNumber(String doorNumber) {
        this.doorNumber = doorNumber;
    }

    public String getFlat() {
        return flat;
    }

    public void setFlat(String flat) {
        this.flat = flat;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Address address = (Address) o;
        return idAddress == address.idAddress && Objects.equals(city, address.city) && Objects.equals(street, address.street) && Objects.equals(numberHouse, address.numberHouse) && Objects.equals(entrance, address.entrance) && Objects.equals(floor, address.floor) && Objects.equals(doorNumber, address.doorNumber)&& Objects.equals(flat, address.flat);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idAddress, city, street, numberHouse, entrance, floor, doorNumber, flat);
    }

    @Override
    public String toString() {
        return "Address{" +
                "idAddress=" + idAddress +
                ", city='" + city + '\'' +
                ", street='" + street + '\'' +
                ", numberHouse='" + numberHouse + '\'' +
                ", entrance='" + entrance + '\'' +
                ", floor='" + floor + '\'' +
                ", doorNumber='" + doorNumber + '\'' +
                ", flat='" + flat + '\'' +
                '}';
    }
}
