package com.example.kyrsovaya4kyrs.service;

import com.example.kyrsovaya4kyrs.model.Feetback;
import com.example.kyrsovaya4kyrs.model.FullFeedback;

import java.util.List;

public interface FeedbackServiceInterface {
    Feetback createFeedback(Feetback feetback);
    Feetback getFeedback(int idFeedback);
    List<Feetback> getAllFeedback();
    List<FullFeedback> getUserFeedbacks(int idUser);
    Feetback deleteFeedback(int idFeedback);
}
