package com.example.kyrsovaya4kyrs.model;

import jakarta.persistence.*;

import java.sql.Date;
import java.util.Objects;

@Entity
public class Feetback {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id_feetback")
    private int idFeetback;
    @Basic
    @Column(name = "id_client")
    private int idClient;
    @Basic
    @Column(name = "id_user")
    private int idUser;
    @Basic
    @Column(name = "text_feetback")
    private String textFeetback;
    @Basic
    @Column(name = "count_stars")
    private int countStars;

    public int getIdFeetback() {
        return idFeetback;
    }

    public void setIdFeetback(int idFeetback) {
        this.idFeetback = idFeetback;
    }

    public int getIdClient() {
        return idClient;
    }

    public void setIdClient(int idClient) {
        this.idClient = idClient;
    }

    public int getIdUser() {
        return idUser;
    }

    public void setIdUser(int idUser) {
        this.idUser = idUser;
    }

    public String getTextFeetback() {
        return textFeetback;
    }

    public void setTextFeetback(String textFeetback) {
        this.textFeetback = textFeetback;
    }

    public int getCountStars() {
        return countStars;
    }

    public void setCountStars(int countStars) {
        this.countStars = countStars;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Feetback feetback = (Feetback) o;
        return idFeetback == feetback.idFeetback && idClient == feetback.idClient && idUser == feetback.idUser && countStars == feetback.countStars && Objects.equals(textFeetback, feetback.textFeetback);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idFeetback, idClient, idUser, textFeetback, countStars);
    }
}
