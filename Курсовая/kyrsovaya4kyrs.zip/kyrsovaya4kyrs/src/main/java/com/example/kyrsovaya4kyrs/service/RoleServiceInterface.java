package com.example.kyrsovaya4kyrs.service;

import com.example.kyrsovaya4kyrs.model.Role;

public interface RoleServiceInterface {
    Role getRole(int idRole);
}
