package com.example.kyrsovaya4kyrs.controller;

import com.example.kyrsovaya4kyrs.model.Client;
import com.example.kyrsovaya4kyrs.service.ClientServiceInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class ClientController {

    @Autowired
    ClientServiceInterface clientService;

    @ResponseBody
    @PostMapping(value = "/createClient")
    public Client createClient(@RequestBody Client client){
        return clientService.createClient(client);
    }
}
