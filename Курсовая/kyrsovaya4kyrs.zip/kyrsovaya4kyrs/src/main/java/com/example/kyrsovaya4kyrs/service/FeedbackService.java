package com.example.kyrsovaya4kyrs.service;

import com.example.kyrsovaya4kyrs.model.*;
import com.example.kyrsovaya4kyrs.repository.FeedbackRepository;
import org.apache.catalina.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class FeedbackService implements FeedbackServiceInterface{

    @Autowired
    FeedbackRepository feedbackRepo;

    @Autowired
    ClientServiceInterface clientService;

    @Autowired
    AddressServiceInterface addressService;

    @Autowired
    UserServiceInterface userService;

    @Autowired
    RoleServiceInterface roleService;

    @Override
    public Feetback createFeedback(Feetback feetback) {
        feedbackRepo.save(feetback);
        return getFeedback(feetback.getIdFeetback());
    }

    @Override
    public Feetback getFeedback(int idFeedback) {
        return feedbackRepo.findById(idFeedback).get();
    }

    @Override
    public List<Feetback> getAllFeedback() {
        return feedbackRepo.findAll();
    }

    @Override
    public List<FullFeedback> getUserFeedbacks(int idUser) {
        List<FullFeedback> userFeedback = new ArrayList<>();
        List<Feetback> allFeedback = feedbackRepo.findAll();

        SystemUser user = userService.getUser(idUser);
        Role role = roleService.getRole(user.getIdRole());

        if(role.getName().equals("Модератор")){
            for (Feetback feedback: allFeedback) {
                Client client = clientService.getClient(feedback.getIdClient());
                Address address = addressService.getAddress(client.getIdAddress());
                FullFeedback fullFeedback = new FullFeedback();
                fullFeedback.setIdFeetback(feedback.getIdFeetback());
                fullFeedback.setCity(address.getCity());
                fullFeedback.setStreet(address.getStreet());
                fullFeedback.setNumberHouse(address.getNumberHouse());
                fullFeedback.setEntrance(address.getEntrance());
                fullFeedback.setFloor(address.getFloor());
                fullFeedback.setDoorNumber(address.getDoorNumber());
                fullFeedback.setFlat(address.getFlat());
                fullFeedback.setName(client.getName());
                fullFeedback.setRating(client.getRating());
                fullFeedback.setComment(feedback.getTextFeetback());
                fullFeedback.setIdAddress(address.getIdAddress());
                fullFeedback.setIdClient(client.getIdClient());

                userFeedback.add(fullFeedback);
            }
        }else{
            for (Feetback feedback: allFeedback) {
                if(feedback.getIdUser() == idUser){
                    Client client = clientService.getClient(feedback.getIdClient());
                    Address address = addressService.getAddress(client.getIdAddress());
                    FullFeedback fullFeedback = new FullFeedback();
                    fullFeedback.setIdFeetback(feedback.getIdFeetback());
                    fullFeedback.setCity(address.getCity());
                    fullFeedback.setStreet(address.getStreet());
                    fullFeedback.setNumberHouse(address.getNumberHouse());
                    fullFeedback.setEntrance(address.getEntrance());
                    fullFeedback.setFloor(address.getFloor());
                    fullFeedback.setDoorNumber(address.getDoorNumber());
                    fullFeedback.setFlat(address.getFlat());
                    fullFeedback.setName(client.getName());
                    fullFeedback.setRating(client.getRating());
                    fullFeedback.setComment(feedback.getTextFeetback());
                    fullFeedback.setIdAddress(address.getIdAddress());
                    fullFeedback.setIdClient(client.getIdClient());

                    userFeedback.add(fullFeedback);
                }
            }
        }

        return userFeedback;
    }

    @Override
    public Feetback deleteFeedback(int idFeedback) {
        feedbackRepo.delete(getFeedback(idFeedback));

        return getFeedback(idFeedback);
    }
}
