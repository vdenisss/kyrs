package com.example.kyrsovaya4kyrs.repository;

import com.example.kyrsovaya4kyrs.model.Role;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoleRepository extends JpaRepository<Role, Integer> {
}
