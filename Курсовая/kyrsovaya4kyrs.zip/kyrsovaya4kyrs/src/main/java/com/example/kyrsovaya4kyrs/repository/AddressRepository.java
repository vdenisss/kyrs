package com.example.kyrsovaya4kyrs.repository;

import com.example.kyrsovaya4kyrs.model.Address;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AddressRepository extends JpaRepository<Address, Integer> {
}
