package com.example.kyrsovaya4kyrs.service;

import com.example.kyrsovaya4kyrs.model.Role;
import com.example.kyrsovaya4kyrs.model.SystemUser;

public interface UserServiceInterface {
    void createUser(String email, String password, int idRole);
    SystemUser updateUser(SystemUser user);
    SystemUser getUser(int idUser);
    SystemUser login(String email, String password);
    String getNameRole(int idRole);
}
