package com.example.kyrsovaya4kyrs.repository;

import com.example.kyrsovaya4kyrs.model.SystemUser;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SystemUserRepository extends JpaRepository<SystemUser, Integer> {
}
