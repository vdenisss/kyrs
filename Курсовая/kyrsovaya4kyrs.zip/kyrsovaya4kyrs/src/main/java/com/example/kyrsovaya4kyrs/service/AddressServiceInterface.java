package com.example.kyrsovaya4kyrs.service;

import com.example.kyrsovaya4kyrs.model.Address;

public interface AddressServiceInterface {
    Address createAddress(Address address);
    Address getAddress(int idAddress);
}
