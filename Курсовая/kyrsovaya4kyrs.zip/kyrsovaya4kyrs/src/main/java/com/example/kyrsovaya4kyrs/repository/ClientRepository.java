package com.example.kyrsovaya4kyrs.repository;

import com.example.kyrsovaya4kyrs.model.Client;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ClientRepository extends JpaRepository<Client, Integer> {
}
