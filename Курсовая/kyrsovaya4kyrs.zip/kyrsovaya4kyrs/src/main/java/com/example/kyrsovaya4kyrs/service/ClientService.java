package com.example.kyrsovaya4kyrs.service;

import com.example.kyrsovaya4kyrs.model.Client;
import com.example.kyrsovaya4kyrs.repository.ClientRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ClientService implements ClientServiceInterface {

    @Autowired
    ClientRepository clientRepo;

    @Override
    public Client createClient(Client client) {
        clientRepo.save(client);
        return getClient(client.getIdClient());
    }

    @Override
    public Client getClient(int idClient) {
        return clientRepo.findById(idClient).get();
    }
}
