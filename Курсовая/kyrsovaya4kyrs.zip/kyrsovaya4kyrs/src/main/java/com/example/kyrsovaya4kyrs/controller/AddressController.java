package com.example.kyrsovaya4kyrs.controller;

import com.example.kyrsovaya4kyrs.model.Address;
import com.example.kyrsovaya4kyrs.service.AddressServiceInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class AddressController {

    @Autowired
    AddressServiceInterface addressService;

    @ResponseBody
    @PostMapping(value = "/createAddress")
    public Address createAddress(@RequestBody Address address){
        return addressService.createAddress(address);
    }

    @ResponseBody
    @PostMapping(value = "/getAddress")
    public Address getAddress(@RequestBody int idAddress){
        return addressService.getAddress(idAddress);
    }

}
