package com.example.kyrsovaya4kyrs.service;

import com.example.kyrsovaya4kyrs.model.Role;
import com.example.kyrsovaya4kyrs.repository.RoleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RoleService implements RoleServiceInterface{

    @Autowired
    RoleRepository roleRepo;

    @Override
    public Role getRole(int idRole) {
        return roleRepo.findById(idRole).get();
    }
}
