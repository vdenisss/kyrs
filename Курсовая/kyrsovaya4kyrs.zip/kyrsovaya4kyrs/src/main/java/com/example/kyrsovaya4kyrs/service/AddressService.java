package com.example.kyrsovaya4kyrs.service;

import com.example.kyrsovaya4kyrs.model.Address;
import com.example.kyrsovaya4kyrs.repository.AddressRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AddressService implements AddressServiceInterface {

    @Autowired
    AddressRepository addressRepo;

    @Override
    public Address createAddress(Address address) {
        addressRepo.save(address);
        return getAddress(address.getIdAddress());
    }

    @Override
    public Address getAddress(int idAddress) {
        return addressRepo.findById(idAddress).get();
    }
}
