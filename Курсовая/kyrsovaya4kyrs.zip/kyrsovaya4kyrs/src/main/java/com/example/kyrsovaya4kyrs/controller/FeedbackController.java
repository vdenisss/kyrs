package com.example.kyrsovaya4kyrs.controller;

import com.example.kyrsovaya4kyrs.model.Feetback;
import com.example.kyrsovaya4kyrs.model.FullFeedback;
import com.example.kyrsovaya4kyrs.model.SystemUser;
import com.example.kyrsovaya4kyrs.service.FeedbackServiceInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

@Controller
public class FeedbackController {

    @Autowired
    FeedbackServiceInterface feedbackService;

    @ResponseBody
    @PostMapping(value = "/createFeedback")
    public ResponseEntity<String> createFeedback(@RequestBody Feetback feetback){
        if(feedbackService.createFeedback(feetback) != null){
            return new ResponseEntity<>(HttpStatus.OK);
        }
        else{
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @ResponseBody
    @PostMapping(value = "/getAllFeedbacks")
    public List<Feetback> getAllFeedback(){
        return feedbackService.getAllFeedback();
    }

    @ResponseBody
    @PostMapping(value = "/getUserFeedback")
    public List<FullFeedback> getUserFeedback(@RequestBody SystemUser user){
        return feedbackService.getUserFeedbacks(user.getIdUser());
    }

    @ResponseBody
    @PostMapping(value = "/deleteFeedback")
    public void deleteFeedback(@RequestBody Feetback feetback) {
        feedbackService.deleteFeedback(feetback.getIdFeetback());
    }
}
